/*!
 * Font Awesome Free 7.2.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
 * Copyright 2026 Fonticons, Inc.
 */
(() => {
    function L(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, a = Array(e); n < e; n++) a[n] = t[n];
        return a;
    }
    function T(t, e) {
        for (var n = 0; n < e.length; n++) {
            var a = e[n];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(t, U(a.key), a);
        }
    }
    function W(t, e) {
        var n, a, r, i, o, s = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
        if (s) return r = !(a = !0), {
            s: function() {
                s = s.call(t);
            },
            n: function() {
                var t = s.next();
                return a = t.done, t;
            },
            e: function(t) {
                r = !0, n = t;
            },
            f: function() {
                try {
                    a || null == s.return || s.return();
                } finally {
                    if (r) throw n;
                }
            }
        };
        if (Array.isArray(t) || (s = J(t)) || e && t && "number" == typeof t.length) return s && (t = s), 
        i = 0, {
            s: o = function() {},
            n: function() {
                return i >= t.length ? {
                    done: !0
                } : {
                    done: !1,
                    value: t[i++]
                };
            },
            e: function(t) {
                throw t;
            },
            f: o
        };
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    function a(t, e, n) {
        return (e = U(e)) in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t;
    }
    function R(e, t) {
        var n, a = Object.keys(e);
        return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(e), 
        t && (n = n.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), a.push.apply(a, n)), a;
    }
    function p(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = null != arguments[t] ? arguments[t] : {};
            t % 2 ? R(Object(n), !0).forEach(function(t) {
                a(e, t, n[t]);
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : R(Object(n)).forEach(function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
            });
        }
        return e;
    }
    function m(t, e) {
        return (t => {
            if (Array.isArray(t)) return t;
        })(t) || ((t, e) => {
            var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != n) {
                var a, r, i, o, s = [], l = !0, f = !1;
                try {
                    if (i = (n = n.call(t)).next, 0 === e) {
                        if (Object(n) !== n) return;
                        l = !1;
                    } else for (;!(l = (a = i.call(n)).done) && (s.push(a.value), 
                    s.length !== e); l = !0);
                } catch (t) {
                    f = !0, r = t;
                } finally {
                    try {
                        if (!l && null != n.return && (o = n.return(), Object(o) !== o)) return;
                    } finally {
                        if (f) throw r;
                    }
                }
                return s;
            }
        })(t, e) || J(t, e) || (() => {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        })();
    }
    function b(t) {
        return (t => {
            if (Array.isArray(t)) return L(t);
        })(t) || (t => {
            if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t);
        })(t) || J(t) || (() => {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
        })();
    }
    function U(t) {
        var e = ((t, e) => {
            if ("object" != typeof t || !t) return t;
            var n = t[Symbol.toPrimitive];
            if (void 0 === n) return ("string" === e ? String : Number)(t);
            if ("object" != typeof (n = n.call(t, e || "default"))) return n;
            throw new TypeError("@@toPrimitive must return a primitive value.");
        })(t, "string");
        return "symbol" == typeof e ? e : e + "";
    }
    function Y(t) {
        return (Y = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t;
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
        })(t);
    }
    function J(t, e) {
        var n;
        if (t) return "string" == typeof t ? L(t, e) : "Map" === (n = "Object" === (n = {}.toString.call(t).slice(8, -1)) && t.constructor ? t.constructor.name : n) || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? L(t, e) : void 0;
    }
    function H() {}
    var t = {}, e = {}, n = null, r = {
        mark: H,
        measure: H
    };
    try {
        "undefined" != typeof window && (t = window), "undefined" != typeof document && (e = document), 
        "undefined" != typeof MutationObserver && (n = MutationObserver), "undefined" != typeof performance && (r = performance);
    } catch (X) {}
    var i = void 0 === (i = (t.navigator || {}).userAgent) ? "" : i, y = t, v = e, B = n, t = r, G = !!y.document, h = !!v.documentElement && !!v.head && "function" == typeof v.addEventListener && "function" == typeof v.createElement, V = ~i.indexOf("MSIE") || ~i.indexOf("Trident/"), e = {
        classic: {
            fa: "solid",
            fas: "solid",
            "fa-solid": "solid",
            far: "regular",
            "fa-regular": "regular",
            fal: "light",
            "fa-light": "light",
            fat: "thin",
            "fa-thin": "thin",
            fab: "brands",
            "fa-brands": "brands"
        },
        duotone: {
            fa: "solid",
            fad: "solid",
            "fa-solid": "solid",
            "fa-duotone": "solid",
            fadr: "regular",
            "fa-regular": "regular",
            fadl: "light",
            "fa-light": "light",
            fadt: "thin",
            "fa-thin": "thin"
        },
        sharp: {
            fa: "solid",
            fass: "solid",
            "fa-solid": "solid",
            fasr: "regular",
            "fa-regular": "regular",
            fasl: "light",
            "fa-light": "light",
            fast: "thin",
            "fa-thin": "thin"
        },
        "sharp-duotone": {
            fa: "solid",
            fasds: "solid",
            "fa-solid": "solid",
            fasdr: "regular",
            "fa-regular": "regular",
            fasdl: "light",
            "fa-light": "light",
            fasdt: "thin",
            "fa-thin": "thin"
        },
        slab: {
            "fa-regular": "regular",
            faslr: "regular"
        },
        "slab-press": {
            "fa-regular": "regular",
            faslpr: "regular"
        },
        thumbprint: {
            "fa-light": "light",
            fatl: "light"
        },
        whiteboard: {
            "fa-semibold": "semibold",
            fawsb: "semibold"
        },
        notdog: {
            "fa-solid": "solid",
            fans: "solid"
        },
        "notdog-duo": {
            "fa-solid": "solid",
            fands: "solid"
        },
        etch: {
            "fa-solid": "solid",
            faes: "solid"
        },
        graphite: {
            "fa-thin": "thin",
            fagt: "thin"
        },
        jelly: {
            "fa-regular": "regular",
            fajr: "regular"
        },
        "jelly-fill": {
            "fa-regular": "regular",
            fajfr: "regular"
        },
        "jelly-duo": {
            "fa-regular": "regular",
            fajdr: "regular"
        },
        chisel: {
            "fa-regular": "regular",
            facr: "regular"
        },
        utility: {
            "fa-semibold": "semibold",
            fausb: "semibold"
        },
        "utility-duo": {
            "fa-semibold": "semibold",
            faudsb: "semibold"
        },
        "utility-fill": {
            "fa-semibold": "semibold",
            faufsb: "semibold"
        }
    }, _ = [ "fa-classic", "fa-duotone", "fa-sharp", "fa-sharp-duotone", "fa-thumbprint", "fa-whiteboard", "fa-notdog", "fa-notdog-duo", "fa-chisel", "fa-etch", "fa-graphite", "fa-jelly", "fa-jelly-fill", "fa-jelly-duo", "fa-slab", "fa-slab-press", "fa-utility", "fa-utility-duo", "fa-utility-fill" ], g = "classic", x = "duotone", X = "notdog-duo", o = "whiteboard", q = [ g, x, n = "sharp", r = "sharp-duotone", i = "chisel", Q = "etch", s = "graphite", l = "jelly", Z = "jelly-duo", f = "jelly-fill", "notdog", X, "slab", ce = "slab-press", c = "thumbprint", nt = "utility", u = "utility-duo", Xe = "utility-fill", o ], K = (a(a(a(a(a(a(a(a(a(a(k = {}, g, "Classic"), x, "Duotone"), n, "Sharp"), r, "Sharp Duotone"), i, "Chisel"), Q, "Etch"), s, "Graphite"), l, "Jelly"), Z, "Jelly Duo"), f, "Jelly Fill"), 
    a(a(a(a(a(a(a(a(a(k, "notdog", "Notdog"), X, "Notdog Duo"), "slab", "Slab"), ce, "Slab Press"), c, "Thumbprint"), nt, "Utility"), u, "Utility Duo"), Xe, "Utility Fill"), o, "Whiteboard"), 
    new Map([ [ "classic", {
        defaultShortPrefixId: "fas",
        defaultStyleId: "solid",
        styleIds: [ "solid", "regular", "light", "thin", "brands" ],
        futureStyleIds: [],
        defaultFontWeight: 900
    } ], [ "duotone", {
        defaultShortPrefixId: "fad",
        defaultStyleId: "solid",
        styleIds: [ "solid", "regular", "light", "thin" ],
        futureStyleIds: [],
        defaultFontWeight: 900
    } ], [ "sharp", {
        defaultShortPrefixId: "fass",
        defaultStyleId: "solid",
        styleIds: [ "solid", "regular", "light", "thin" ],
        futureStyleIds: [],
        defaultFontWeight: 900
    } ], [ "sharp-duotone", {
        defaultShortPrefixId: "fasds",
        defaultStyleId: "solid",
        styleIds: [ "solid", "regular", "light", "thin" ],
        futureStyleIds: [],
        defaultFontWeight: 900
    } ], [ "chisel", {
        defaultShortPrefixId: "facr",
        defaultStyleId: "regular",
        styleIds: [ "regular" ],
        futureStyleIds: [],
        defaultFontWeight: 400
    } ], [ "etch", {
        defaultShortPrefixId: "faes",
        defaultStyleId: "solid",
        styleIds: [ "solid" ],
        futureStyleIds: [],
        defaultFontWeight: 900
    } ], [ "graphite", {
        defaultShortPrefixId: "fagt",
        defaultStyleId: "thin",
        styleIds: [ "thin" ],
        futureStyleIds: [],
        defaultFontWeight: 100
    } ], [ "jelly", {
        defaultShortPrefixId: "fajr",
        defaultStyleId: "regular",
        styleIds: [ "regular" ],
        futureStyleIds: [],
        defaultFontWeight: 400
    } ], [ "jelly-duo", {
        defaultShortPrefixId: "fajdr",
        defaultStyleId: "regular",
        styleIds: [ "regular" ],
        futureStyleIds: [],
        defaultFontWeight: 400
    } ], [ "jelly-fill", {
        defaultShortPrefixId: "fajfr",
        defaultStyleId: "regular",
        styleIds: [ "regular" ],
        futureStyleIds: [],
        defaultFontWeight: 400
    } ], [ "notdog", {
        defaultShortPrefixId: "fans",
        defaultStyleId: "solid",
        styleIds: [ "solid" ],
        futureStyleIds: [],
        defaultFontWeight: 900
    } ], [ "notdog-duo", {
        defaultShortPrefixId: "fands",
        defaultStyleId: "solid",
        styleIds: [ "solid" ],
        futureStyleIds: [],
        defaultFontWeight: 900
    } ], [ "slab", {
        defaultShortPrefixId: "faslr",
        defaultStyleId: "regular",
        styleIds: [ "regular" ],
        futureStyleIds: [],
        defaultFontWeight: 400
    } ], [ "slab-press", {
        defaultShortPrefixId: "faslpr",
        defaultStyleId: "regular",
        styleIds: [ "regular" ],
        futureStyleIds: [],
        defaultFontWeight: 400
    } ], [ "thumbprint", {
        defaultShortPrefixId: "fatl",
        defaultStyleId: "light",
        styleIds: [ "light" ],
        futureStyleIds: [],
        defaultFontWeight: 300
    } ], [ "utility", {
        defaultShortPrefixId: "fausb",
        defaultStyleId: "semibold",
        styleIds: [ "semibold" ],
        futureStyleIds: [],
        defaultFontWeight: 600
    } ], [ "utility-duo", {
        defaultShortPrefixId: "faudsb",
        defaultStyleId: "semibold",
        styleIds: [ "semibold" ],
        futureStyleIds: [],
        defaultFontWeight: 600
    } ], [ "utility-fill", {
        defaultShortPrefixId: "faufsb",
        defaultStyleId: "semibold",
        styleIds: [ "semibold" ],
        futureStyleIds: [],
        defaultFontWeight: 600
    } ], [ "whiteboard", {
        defaultShortPrefixId: "fawsb",
        defaultStyleId: "semibold",
        styleIds: [ "semibold" ],
        futureStyleIds: [],
        defaultFontWeight: 600
    } ] ])), $ = [ "fak", "fa-kit", "fakd", "fa-kit-duotone" ], n = {
        fak: "kit",
        "fa-kit": "kit"
    }, r = {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
    }, i = (a(a({}, "kit", "Kit"), "kit-duotone", "Kit Duotone"), {
        kit: "fak"
    }), Q = {
        "kit-duotone": "fakd"
    }, s = "duotone-group", l = "swap-opacity", Z = "primary", f = "secondary", tt = (a(a(a(a(a(a(a(a(a(a(k = {}, "classic", "Classic"), "duotone", "Duotone"), "sharp", "Sharp"), "sharp-duotone", "Sharp Duotone"), "chisel", "Chisel"), "etch", "Etch"), "graphite", "Graphite"), "jelly", "Jelly"), "jelly-duo", "Jelly Duo"), "jelly-fill", "Jelly Fill"), 
    a(a(a(a(a(a(a(a(a(k, "notdog", "Notdog"), "notdog-duo", "Notdog Duo"), "slab", "Slab"), "slab-press", "Slab Press"), "thumbprint", "Thumbprint"), "utility", "Utility"), "utility-duo", "Utility Duo"), "utility-fill", "Utility Fill"), "whiteboard", "Whiteboard"), 
    a(a({}, "kit", "Kit"), "kit-duotone", "Kit Duotone"), {
        classic: {
            fab: "fa-brands",
            fad: "fa-duotone",
            fal: "fa-light",
            far: "fa-regular",
            fas: "fa-solid",
            fat: "fa-thin"
        },
        duotone: {
            fadr: "fa-regular",
            fadl: "fa-light",
            fadt: "fa-thin"
        },
        sharp: {
            fass: "fa-solid",
            fasr: "fa-regular",
            fasl: "fa-light",
            fast: "fa-thin"
        },
        "sharp-duotone": {
            fasds: "fa-solid",
            fasdr: "fa-regular",
            fasdl: "fa-light",
            fasdt: "fa-thin"
        },
        slab: {
            faslr: "fa-regular"
        },
        "slab-press": {
            faslpr: "fa-regular"
        },
        whiteboard: {
            fawsb: "fa-semibold"
        },
        thumbprint: {
            fatl: "fa-light"
        },
        notdog: {
            fans: "fa-solid"
        },
        "notdog-duo": {
            fands: "fa-solid"
        },
        etch: {
            faes: "fa-solid"
        },
        graphite: {
            fagt: "fa-thin"
        },
        jelly: {
            fajr: "fa-regular"
        },
        "jelly-fill": {
            fajfr: "fa-regular"
        },
        "jelly-duo": {
            fajdr: "fa-regular"
        },
        chisel: {
            facr: "fa-regular"
        },
        utility: {
            fausb: "fa-semibold"
        },
        "utility-duo": {
            faudsb: "fa-semibold"
        },
        "utility-fill": {
            faufsb: "fa-semibold"
        }
    }), et = [ "fa", "fas", "far", "fal", "fat", "fad", "fadr", "fadl", "fadt", "fab", "fass", "fasr", "fasl", "fast", "fasds", "fasdr", "fasdl", "fasdt", "faslr", "faslpr", "fawsb", "fatl", "fans", "fands", "faes", "fagt", "fajr", "fajfr", "fajdr", "facr", "fausb", "faudsb", "faufsb" ].concat([ "fa-classic", "fa-duotone", "fa-sharp", "fa-sharp-duotone", "fa-thumbprint", "fa-whiteboard", "fa-notdog", "fa-notdog-duo", "fa-chisel", "fa-etch", "fa-graphite", "fa-jelly", "fa-jelly-fill", "fa-jelly-duo", "fa-slab", "fa-slab-press", "fa-utility", "fa-utility-duo", "fa-utility-fill" ], [ "fa-solid", "fa-regular", "fa-light", "fa-thin", "fa-duotone", "fa-brands", "fa-semibold" ]), c = (ce = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]).concat([ 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 ]), nt = [].concat(b(Object.keys({
        classic: [ "fas", "far", "fal", "fat", "fad" ],
        duotone: [ "fadr", "fadl", "fadt" ],
        sharp: [ "fass", "fasr", "fasl", "fast" ],
        "sharp-duotone": [ "fasds", "fasdr", "fasdl", "fasdt" ],
        slab: [ "faslr" ],
        "slab-press": [ "faslpr" ],
        whiteboard: [ "fawsb" ],
        thumbprint: [ "fatl" ],
        notdog: [ "fans" ],
        "notdog-duo": [ "fands" ],
        etch: [ "faes" ],
        graphite: [ "fagt" ],
        jelly: [ "fajr" ],
        "jelly-fill": [ "fajfr" ],
        "jelly-duo": [ "fajdr" ],
        chisel: [ "facr" ],
        utility: [ "fausb" ],
        "utility-duo": [ "faudsb" ],
        "utility-fill": [ "faufsb" ]
    })), [ "solid", "regular", "light", "thin", "duotone", "brands", "semibold" ], [ "aw", "fw", "pull-left", "pull-right" ], [ "2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "border", "fade", "beat-fade", "bounce", "flip-both", "flip-horizontal", "flip-vertical", "flip", "inverse", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "stack-1x", "stack-2x", "stack", "ul", "width-auto", "width-fixed", s, l, Z, f ]).concat(ce.map(function(t) {
        return "".concat(t, "x");
    })).concat(c.map(function(t) {
        return "w-".concat(t);
    })), u = "___FONT_AWESOME___", at = 16, rt = "svg-inline--fa", w = "data-fa-i2svg", it = "data-fa-pseudo-element", ot = "data-fa-pseudo-element-pending", st = "data-prefix", lt = "data-icon", ft = "fontawesome-i2svg", ct = "async", ut = [ "HTML", "HEAD", "STYLE", "SCRIPT" ], dt = [ "::before", "::after", ":before", ":after" ], mt = (() => {
        try {
            return !1;
        } catch (t) {
            return !1;
        }
    })();
    function d(t) {
        return new Proxy(t, {
            get: function(t, e) {
                return e in t ? t[e] : t[g];
            }
        });
    }
    (Xe = p({}, e))[g] = p(p(p(p({}, {
        "fa-duotone": "duotone"
    }), e[g]), n), r);
    var ht = d(Xe), gt = ((o = p({}, {
        chisel: {
            regular: "facr"
        },
        classic: {
            brands: "fab",
            light: "fal",
            regular: "far",
            solid: "fas",
            thin: "fat"
        },
        duotone: {
            light: "fadl",
            regular: "fadr",
            solid: "fad",
            thin: "fadt"
        },
        etch: {
            solid: "faes"
        },
        graphite: {
            thin: "fagt"
        },
        jelly: {
            regular: "fajr"
        },
        "jelly-duo": {
            regular: "fajdr"
        },
        "jelly-fill": {
            regular: "fajfr"
        },
        notdog: {
            solid: "fans"
        },
        "notdog-duo": {
            solid: "fands"
        },
        sharp: {
            light: "fasl",
            regular: "fasr",
            solid: "fass",
            thin: "fast"
        },
        "sharp-duotone": {
            light: "fasdl",
            regular: "fasdr",
            solid: "fasds",
            thin: "fasdt"
        },
        slab: {
            regular: "faslr"
        },
        "slab-press": {
            regular: "faslpr"
        },
        thumbprint: {
            light: "fatl"
        },
        utility: {
            semibold: "fausb"
        },
        "utility-duo": {
            semibold: "faudsb"
        },
        "utility-fill": {
            semibold: "faufsb"
        },
        whiteboard: {
            semibold: "fawsb"
        }
    }))[g] = p(p(p(p({}, {
        duotone: "fad"
    }), o[g]), i), Q), d(o)), k = p({}, tt), pt = (k[g] = p(p({}, k[g]), {
        fak: "fa-kit"
    }), d(k)), bt = ((s = p({}, {
        classic: {
            "fa-brands": "fab",
            "fa-duotone": "fad",
            "fa-light": "fal",
            "fa-regular": "far",
            "fa-solid": "fas",
            "fa-thin": "fat"
        },
        duotone: {
            "fa-regular": "fadr",
            "fa-light": "fadl",
            "fa-thin": "fadt"
        },
        sharp: {
            "fa-solid": "fass",
            "fa-regular": "fasr",
            "fa-light": "fasl",
            "fa-thin": "fast"
        },
        "sharp-duotone": {
            "fa-solid": "fasds",
            "fa-regular": "fasdr",
            "fa-light": "fasdl",
            "fa-thin": "fasdt"
        },
        slab: {
            "fa-regular": "faslr"
        },
        "slab-press": {
            "fa-regular": "faslpr"
        },
        whiteboard: {
            "fa-semibold": "fawsb"
        },
        thumbprint: {
            "fa-light": "fatl"
        },
        notdog: {
            "fa-solid": "fans"
        },
        "notdog-duo": {
            "fa-solid": "fands"
        },
        etch: {
            "fa-solid": "faes"
        },
        graphite: {
            "fa-thin": "fagt"
        },
        jelly: {
            "fa-regular": "fajr"
        },
        "jelly-fill": {
            "fa-regular": "fajfr"
        },
        "jelly-duo": {
            "fa-regular": "fajdr"
        },
        chisel: {
            "fa-regular": "facr"
        },
        utility: {
            "fa-semibold": "fausb"
        },
        "utility-duo": {
            "fa-semibold": "faudsb"
        },
        "utility-fill": {
            "fa-semibold": "faufsb"
        }
    }))[g] = p(p({}, s[g]), {
        "fa-kit": "fak"
    }), d(s), /fa(k|kd|s|r|l|t|d|dr|dl|dt|b|slr|slpr|wsb|tl|ns|nds|es|gt|jr|jfr|jdr|usb|ufsb|udsb|cr|ss|sr|sl|st|sds|sdr|sdl|sdt)?[\-\ ]/), yt = "fa-layers-text", vt = /Font ?Awesome ?([567 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp Duotone|Sharp|Kit|Notdog Duo|Notdog|Chisel|Etch|Graphite|Thumbprint|Jelly Fill|Jelly Duo|Jelly|Utility|Utility Fill|Utility Duo|Slab Press|Slab|Whiteboard)?.*/i, xt = (d(p({}, {
        classic: {
            900: "fas",
            400: "far",
            normal: "far",
            300: "fal",
            100: "fat"
        },
        duotone: {
            900: "fad",
            400: "fadr",
            300: "fadl",
            100: "fadt"
        },
        sharp: {
            900: "fass",
            400: "fasr",
            300: "fasl",
            100: "fast"
        },
        "sharp-duotone": {
            900: "fasds",
            400: "fasdr",
            300: "fasdl",
            100: "fasdt"
        },
        slab: {
            400: "faslr"
        },
        "slab-press": {
            400: "faslpr"
        },
        whiteboard: {
            600: "fawsb"
        },
        thumbprint: {
            300: "fatl"
        },
        notdog: {
            900: "fans"
        },
        "notdog-duo": {
            900: "fands"
        },
        etch: {
            900: "faes"
        },
        graphite: {
            100: "fagt"
        },
        chisel: {
            400: "facr"
        },
        jelly: {
            400: "fajr"
        },
        "jelly-fill": {
            400: "fajfr"
        },
        "jelly-duo": {
            400: "fajdr"
        },
        utility: {
            600: "fausb"
        },
        "utility-duo": {
            600: "faudsb"
        },
        "utility-fill": {
            600: "faufsb"
        }
    })), [ "class", "data-prefix", "data-icon", "data-fa-transform", "data-fa-mask" ]), wt = {
        GROUP: "duotone-group",
        SWAP_OPACITY: "swap-opacity",
        PRIMARY: "primary",
        SECONDARY: "secondary"
    }, kt = [].concat(b([ "kit" ]), b(nt)), S = y.FontAwesomeConfig || {}, l = (v && "function" == typeof v.querySelector && [ [ "data-family-prefix", "familyPrefix" ], [ "data-css-prefix", "cssPrefix" ], [ "data-family-default", "familyDefault" ], [ "data-style-default", "styleDefault" ], [ "data-replacement-class", "replacementClass" ], [ "data-auto-replace-svg", "autoReplaceSvg" ], [ "data-auto-add-css", "autoAddCss" ], [ "data-search-pseudo-elements", "searchPseudoElements" ], [ "data-search-pseudo-elements-warnings", "searchPseudoElementsWarnings" ], [ "data-search-pseudo-elements-full-scan", "searchPseudoElementsFullScan" ], [ "data-observe-mutations", "observeMutations" ], [ "data-mutate-approach", "mutateApproach" ], [ "data-keep-original-source", "keepOriginalSource" ], [ "data-measure-performance", "measurePerformance" ], [ "data-show-missing-icons", "showMissingIcons" ] ].forEach(function(t) {
        var e = m(t, 2), n = e[0], e = e[1], n = "" === (t = (t => {
            var e = v.querySelector("script[" + t + "]");
            if (e) return e.getAttribute(t);
        })(n)) || "false" !== t && ("true" === t || t);
        null != n && (S[e] = n);
    }), {
        styleDefault: "solid",
        familyDefault: g,
        cssPrefix: "fa",
        replacementClass: rt,
        autoReplaceSvg: !0,
        autoAddCss: !0,
        searchPseudoElements: !1,
        searchPseudoElementsWarnings: !0,
        searchPseudoElementsFullScan: !1,
        observeMutations: !0,
        mutateApproach: "async",
        keepOriginalSource: !0,
        measurePerformance: !1,
        showMissingIcons: !0
    }), A = (S.familyPrefix && (S.cssPrefix = S.familyPrefix), p(p({}, l), S)), j = (A.autoReplaceSvg || (A.observeMutations = !1), 
    {}), St = (Object.keys(l).forEach(function(e) {
        Object.defineProperty(j, e, {
            enumerable: !0,
            set: function(t) {
                A[e] = t, St.forEach(function(t) {
                    return t(j);
                });
            },
            get: function() {
                return A[e];
            }
        });
    }), Object.defineProperty(j, "familyPrefix", {
        enumerable: !0,
        set: function(t) {
            A.cssPrefix = t, St.forEach(function(t) {
                return t(j);
            });
        },
        get: function() {
            return A.cssPrefix;
        }
    }), y.FontAwesomeConfig = j, []), P = at, F = {
        size: 16,
        x: 0,
        y: 0,
        rotate: 0,
        flipX: !1,
        flipY: !1
    };
    function At() {
        for (var t = 12, e = ""; 0 < t--; ) e += "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"[62 * Math.random() | 0];
        return e;
    }
    function I(t) {
        for (var e = [], n = (t || []).length >>> 0; n--; ) e[n] = t[n];
        return e;
    }
    function jt(t) {
        return t.classList ? I(t.classList) : (t.getAttribute("class") || "").split(" ").filter(function(t) {
            return t;
        });
    }
    function Pt(t) {
        return "".concat(t).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    function Ft(n) {
        return Object.keys(n || {}).reduce(function(t, e) {
            return t + "".concat(e, ": ").concat(n[e].trim(), ";");
        }, "");
    }
    function It(t) {
        return t.size !== F.size || t.x !== F.x || t.y !== F.y || t.rotate !== F.rotate || t.flipX || t.flipY;
    }
    function Nt() {
        var t, e, n = rt, a = j.cssPrefix, r = j.replacementClass, i = ":root, :host {\n  --fa-font-solid: normal 900 1em/1 'Font Awesome 7 Free';\n  --fa-font-regular: normal 400 1em/1 'Font Awesome 7 Free';\n  --fa-font-light: normal 300 1em/1 'Font Awesome 7 Pro';\n  --fa-font-thin: normal 100 1em/1 'Font Awesome 7 Pro';\n  --fa-font-duotone: normal 900 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-regular: normal 400 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-light: normal 300 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-duotone-thin: normal 100 1em/1 'Font Awesome 7 Duotone';\n  --fa-font-brands: normal 400 1em/1 'Font Awesome 7 Brands';\n  --fa-font-sharp-solid: normal 900 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-regular: normal 400 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-light: normal 300 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-thin: normal 100 1em/1 'Font Awesome 7 Sharp';\n  --fa-font-sharp-duotone-solid: normal 900 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-regular: normal 400 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-light: normal 300 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-sharp-duotone-thin: normal 100 1em/1 'Font Awesome 7 Sharp Duotone';\n  --fa-font-slab-regular: normal 400 1em/1 'Font Awesome 7 Slab';\n  --fa-font-slab-press-regular: normal 400 1em/1 'Font Awesome 7 Slab Press';\n  --fa-font-whiteboard-semibold: normal 600 1em/1 'Font Awesome 7 Whiteboard';\n  --fa-font-thumbprint-light: normal 300 1em/1 'Font Awesome 7 Thumbprint';\n  --fa-font-notdog-solid: normal 900 1em/1 'Font Awesome 7 Notdog';\n  --fa-font-notdog-duo-solid: normal 900 1em/1 'Font Awesome 7 Notdog Duo';\n  --fa-font-etch-solid: normal 900 1em/1 'Font Awesome 7 Etch';\n  --fa-font-graphite-thin: normal 100 1em/1 'Font Awesome 7 Graphite';\n  --fa-font-jelly-regular: normal 400 1em/1 'Font Awesome 7 Jelly';\n  --fa-font-jelly-fill-regular: normal 400 1em/1 'Font Awesome 7 Jelly Fill';\n  --fa-font-jelly-duo-regular: normal 400 1em/1 'Font Awesome 7 Jelly Duo';\n  --fa-font-chisel-regular: normal 400 1em/1 'Font Awesome 7 Chisel';\n  --fa-font-utility-semibold: normal 600 1em/1 'Font Awesome 7 Utility';\n  --fa-font-utility-duo-semibold: normal 600 1em/1 'Font Awesome 7 Utility Duo';\n  --fa-font-utility-fill-semibold: normal 600 1em/1 'Font Awesome 7 Utility Fill';\n}\n\n.svg-inline--fa {\n  box-sizing: content-box;\n  display: var(--fa-display, inline-block);\n  height: 1em;\n  overflow: visible;\n  vertical-align: -0.125em;\n  width: var(--fa-width, 1.25em);\n}\n.svg-inline--fa.fa-2xs {\n  vertical-align: 0.1em;\n}\n.svg-inline--fa.fa-xs {\n  vertical-align: 0em;\n}\n.svg-inline--fa.fa-sm {\n  vertical-align: -0.0714285714em;\n}\n.svg-inline--fa.fa-lg {\n  vertical-align: -0.2em;\n}\n.svg-inline--fa.fa-xl {\n  vertical-align: -0.25em;\n}\n.svg-inline--fa.fa-2xl {\n  vertical-align: -0.3125em;\n}\n.svg-inline--fa.fa-pull-left,\n.svg-inline--fa .fa-pull-start {\n  float: inline-start;\n  margin-inline-end: var(--fa-pull-margin, 0.3em);\n}\n.svg-inline--fa.fa-pull-right,\n.svg-inline--fa .fa-pull-end {\n  float: inline-end;\n  margin-inline-start: var(--fa-pull-margin, 0.3em);\n}\n.svg-inline--fa.fa-li {\n  width: var(--fa-li-width, 2em);\n  inset-inline-start: calc(-1 * var(--fa-li-width, 2em));\n  inset-block-start: 0.25em; /* syncing vertical alignment with Web Font rendering */\n}\n\n.fa-layers-counter, .fa-layers-text {\n  display: inline-block;\n  position: absolute;\n  text-align: center;\n}\n\n.fa-layers {\n  display: inline-block;\n  height: 1em;\n  position: relative;\n  text-align: center;\n  vertical-align: -0.125em;\n  width: var(--fa-width, 1.25em);\n}\n.fa-layers .svg-inline--fa {\n  inset: 0;\n  margin: auto;\n  position: absolute;\n  transform-origin: center center;\n}\n\n.fa-layers-text {\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n  transform-origin: center center;\n}\n\n.fa-layers-counter {\n  background-color: var(--fa-counter-background-color, #ff253a);\n  border-radius: var(--fa-counter-border-radius, 1em);\n  box-sizing: border-box;\n  color: var(--fa-inverse, #fff);\n  line-height: var(--fa-counter-line-height, 1);\n  max-width: var(--fa-counter-max-width, 5em);\n  min-width: var(--fa-counter-min-width, 1.5em);\n  overflow: hidden;\n  padding: var(--fa-counter-padding, 0.25em 0.5em);\n  right: var(--fa-right, 0);\n  text-overflow: ellipsis;\n  top: var(--fa-top, 0);\n  transform: scale(var(--fa-counter-scale, 0.25));\n  transform-origin: top right;\n}\n\n.fa-layers-bottom-right {\n  bottom: var(--fa-bottom, 0);\n  right: var(--fa-right, 0);\n  top: auto;\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: bottom right;\n}\n\n.fa-layers-bottom-left {\n  bottom: var(--fa-bottom, 0);\n  left: var(--fa-left, 0);\n  right: auto;\n  top: auto;\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: bottom left;\n}\n\n.fa-layers-top-right {\n  top: var(--fa-top, 0);\n  right: var(--fa-right, 0);\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: top right;\n}\n\n.fa-layers-top-left {\n  left: var(--fa-left, 0);\n  right: auto;\n  top: var(--fa-top, 0);\n  transform: scale(var(--fa-layers-scale, 0.25));\n  transform-origin: top left;\n}\n\n.fa-1x {\n  font-size: 1em;\n}\n\n.fa-2x {\n  font-size: 2em;\n}\n\n.fa-3x {\n  font-size: 3em;\n}\n\n.fa-4x {\n  font-size: 4em;\n}\n\n.fa-5x {\n  font-size: 5em;\n}\n\n.fa-6x {\n  font-size: 6em;\n}\n\n.fa-7x {\n  font-size: 7em;\n}\n\n.fa-8x {\n  font-size: 8em;\n}\n\n.fa-9x {\n  font-size: 9em;\n}\n\n.fa-10x {\n  font-size: 10em;\n}\n\n.fa-2xs {\n  font-size: calc(10 / 16 * 1em); /* converts a 10px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 10 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 10 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-xs {\n  font-size: calc(12 / 16 * 1em); /* converts a 12px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 12 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 12 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-sm {\n  font-size: calc(14 / 16 * 1em); /* converts a 14px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 14 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 14 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-lg {\n  font-size: calc(20 / 16 * 1em); /* converts a 20px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 20 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 20 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-xl {\n  font-size: calc(24 / 16 * 1em); /* converts a 24px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 24 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 24 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-2xl {\n  font-size: calc(32 / 16 * 1em); /* converts a 32px size into an em-based value that's relative to the scale's 16px base */\n  line-height: calc(1 / 32 * 1em); /* sets the line-height of the icon back to that of it's parent */\n  vertical-align: calc((6 / 32 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */\n}\n\n.fa-width-auto {\n  --fa-width: auto;\n}\n\n.fa-fw,\n.fa-width-fixed {\n  --fa-width: 1.25em;\n}\n\n.fa-ul {\n  list-style-type: none;\n  margin-inline-start: var(--fa-li-margin, 2.5em);\n  padding-inline-start: 0;\n}\n.fa-ul > li {\n  position: relative;\n}\n\n.fa-li {\n  inset-inline-start: calc(-1 * var(--fa-li-width, 2em));\n  position: absolute;\n  text-align: center;\n  width: var(--fa-li-width, 2em);\n  line-height: inherit;\n}\n\n/* Heads Up: Bordered Icons will not be supported in the future!\n  - This feature will be deprecated in the next major release of Font Awesome (v8)!\n  - You may continue to use it in this version *v7), but it will not be supported in Font Awesome v8.\n*/\n/* Notes:\n* --@{v.$css-prefix}-border-width = 1/16 by default (to render as ~1px based on a 16px default font-size)\n* --@{v.$css-prefix}-border-padding =\n  ** 3/16 for vertical padding (to give ~2px of vertical whitespace around an icon considering it's vertical alignment)\n  ** 4/16 for horizontal padding (to give ~4px of horizontal whitespace around an icon)\n*/\n.fa-border {\n  border-color: var(--fa-border-color, #eee);\n  border-radius: var(--fa-border-radius, 0.1em);\n  border-style: var(--fa-border-style, solid);\n  border-width: var(--fa-border-width, 0.0625em);\n  box-sizing: var(--fa-border-box-sizing, content-box);\n  padding: var(--fa-border-padding, 0.1875em 0.25em);\n}\n\n.fa-pull-left,\n.fa-pull-start {\n  float: inline-start;\n  margin-inline-end: var(--fa-pull-margin, 0.3em);\n}\n\n.fa-pull-right,\n.fa-pull-end {\n  float: inline-end;\n  margin-inline-start: var(--fa-pull-margin, 0.3em);\n}\n\n.fa-beat {\n  animation-name: fa-beat;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, ease-in-out);\n}\n\n.fa-bounce {\n  animation-name: fa-bounce;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));\n}\n\n.fa-fade {\n  animation-name: fa-fade;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n}\n\n.fa-beat-fade {\n  animation-name: fa-beat-fade;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));\n}\n\n.fa-flip {\n  animation-name: fa-flip;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, ease-in-out);\n}\n\n.fa-shake {\n  animation-name: fa-shake;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, linear);\n}\n\n.fa-spin {\n  animation-name: fa-spin;\n  animation-delay: var(--fa-animation-delay, 0s);\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 2s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, linear);\n}\n\n.fa-spin-reverse {\n  --fa-animation-direction: reverse;\n}\n\n.fa-pulse,\n.fa-spin-pulse {\n  animation-name: fa-spin;\n  animation-direction: var(--fa-animation-direction, normal);\n  animation-duration: var(--fa-animation-duration, 1s);\n  animation-iteration-count: var(--fa-animation-iteration-count, infinite);\n  animation-timing-function: var(--fa-animation-timing, steps(8));\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .fa-beat,\n  .fa-bounce,\n  .fa-fade,\n  .fa-beat-fade,\n  .fa-flip,\n  .fa-pulse,\n  .fa-shake,\n  .fa-spin,\n  .fa-spin-pulse {\n    animation: none !important;\n    transition: none !important;\n  }\n}\n@keyframes fa-beat {\n  0%, 90% {\n    transform: scale(1);\n  }\n  45% {\n    transform: scale(var(--fa-beat-scale, 1.25));\n  }\n}\n@keyframes fa-bounce {\n  0% {\n    transform: scale(1, 1) translateY(0);\n  }\n  10% {\n    transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);\n  }\n  30% {\n    transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));\n  }\n  50% {\n    transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);\n  }\n  57% {\n    transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));\n  }\n  64% {\n    transform: scale(1, 1) translateY(0);\n  }\n  100% {\n    transform: scale(1, 1) translateY(0);\n  }\n}\n@keyframes fa-fade {\n  50% {\n    opacity: var(--fa-fade-opacity, 0.4);\n  }\n}\n@keyframes fa-beat-fade {\n  0%, 100% {\n    opacity: var(--fa-beat-fade-opacity, 0.4);\n    transform: scale(1);\n  }\n  50% {\n    opacity: 1;\n    transform: scale(var(--fa-beat-fade-scale, 1.125));\n  }\n}\n@keyframes fa-flip {\n  50% {\n    transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));\n  }\n}\n@keyframes fa-shake {\n  0% {\n    transform: rotate(-15deg);\n  }\n  4% {\n    transform: rotate(15deg);\n  }\n  8%, 24% {\n    transform: rotate(-18deg);\n  }\n  12%, 28% {\n    transform: rotate(18deg);\n  }\n  16% {\n    transform: rotate(-22deg);\n  }\n  20% {\n    transform: rotate(22deg);\n  }\n  32% {\n    transform: rotate(-12deg);\n  }\n  36% {\n    transform: rotate(12deg);\n  }\n  40%, 100% {\n    transform: rotate(0deg);\n  }\n}\n@keyframes fa-spin {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n.fa-rotate-90 {\n  transform: rotate(90deg);\n}\n\n.fa-rotate-180 {\n  transform: rotate(180deg);\n}\n\n.fa-rotate-270 {\n  transform: rotate(270deg);\n}\n\n.fa-flip-horizontal {\n  transform: scale(-1, 1);\n}\n\n.fa-flip-vertical {\n  transform: scale(1, -1);\n}\n\n.fa-flip-both,\n.fa-flip-horizontal.fa-flip-vertical {\n  transform: scale(-1, -1);\n}\n\n.fa-rotate-by {\n  transform: rotate(var(--fa-rotate-angle, 0));\n}\n\n.svg-inline--fa .fa-primary {\n  fill: var(--fa-primary-color, currentColor);\n  opacity: var(--fa-primary-opacity, 1);\n}\n\n.svg-inline--fa .fa-secondary {\n  fill: var(--fa-secondary-color, currentColor);\n  opacity: var(--fa-secondary-opacity, 0.4);\n}\n\n.svg-inline--fa.fa-swap-opacity .fa-primary {\n  opacity: var(--fa-secondary-opacity, 0.4);\n}\n\n.svg-inline--fa.fa-swap-opacity .fa-secondary {\n  opacity: var(--fa-primary-opacity, 1);\n}\n\n.svg-inline--fa mask .fa-primary,\n.svg-inline--fa mask .fa-secondary {\n  fill: black;\n}\n\n.svg-inline--fa.fa-inverse {\n  fill: var(--fa-inverse, #fff);\n}\n\n.fa-stack {\n  display: inline-block;\n  height: 2em;\n  line-height: 2em;\n  position: relative;\n  vertical-align: middle;\n  width: 2.5em;\n}\n\n.fa-inverse {\n  color: var(--fa-inverse, #fff);\n}\n\n.svg-inline--fa.fa-stack-1x {\n  --fa-width: 1.25em;\n  height: 1em;\n  width: var(--fa-width);\n}\n.svg-inline--fa.fa-stack-2x {\n  --fa-width: 2.5em;\n  height: 2em;\n  width: var(--fa-width);\n}\n\n.fa-stack-1x,\n.fa-stack-2x {\n  inset: 0;\n  margin: auto;\n  position: absolute;\n  z-index: var(--fa-stack-z-index, auto);\n}";
        return "fa" === a && r === n || (t = new RegExp("\\.".concat("fa", "\\-"), "g"), 
        e = new RegExp("\\--".concat("fa", "\\-"), "g"), n = new RegExp("\\.".concat(n), "g"), 
        i = i.replace(t, ".".concat(a, "-")).replace(e, "--".concat(a, "-")).replace(n, ".".concat(r))), 
        i;
    }
    var Ot = !1;
    function Et() {
        if (j.autoAddCss && !Ot) {
            var t = Nt();
            if (t && h) {
                for (var e = v.createElement("style"), n = (e.setAttribute("type", "text/css"), 
                e.innerHTML = t, v.head.childNodes), a = null, r = n.length - 1; -1 < r; r--) {
                    var i = n[r], o = (i.tagName || "").toUpperCase();
                    -1 < [ "STYLE", "LINK" ].indexOf(o) && (a = i);
                }
                v.head.insertBefore(e, a);
            }
            Ot = !0;
        }
    }
    function Ct() {
        v.removeEventListener("DOMContentLoaded", Ct), Dt = 1, zt.map(function(t) {
            return t();
        });
    }
    var Z = {
        mixout: function() {
            return {
                dom: {
                    css: Nt,
                    insertCss: Et
                }
            };
        },
        hooks: function() {
            return {
                beforeDOMElementCreation: function() {
                    Et();
                },
                beforeI2svg: function() {
                    Et();
                }
            };
        }
    }, N = ((f = y || {})[u] || (f[u] = {}), f[u].styles || (f[u].styles = {}), 
    f[u].hooks || (f[u].hooks = {}), f[u].shims || (f[u].shims = []), f[u]), zt = [], Dt = !1;
    function Mt(t) {
        h && (Dt ? setTimeout(t, 0) : zt.push(t));
    }
    function Lt(t) {
        var n, e = t.tag, a = t.attributes, a = void 0 === a ? {} : a, r = t.children, r = void 0 === r ? [] : r;
        return "string" == typeof t ? Pt(t) : "<".concat(e, " ").concat((n = a, 
        Object.keys(n || {}).reduce(function(t, e) {
            return t + "".concat(e, '="').concat(Pt(n[e]), '" ');
        }, "").trim()), ">").concat(r.map(Lt).join(""), "</").concat(e, ">");
    }
    function Tt(t, e, n) {
        if (t && t[e] && t[e][n]) return {
            prefix: e,
            iconName: n,
            icon: t[e][n]
        };
    }
    function Wt(t, e, n, a) {
        for (var r, i, o = Object.keys(t), s = o.length, l = void 0 !== a ? Rt(e, a) : e, f = void 0 === n ? (r = 1, 
        t[o[0]]) : (r = 0, n); r < s; r++) f = l(f, t[i = o[r]], i, t);
        return f;
    }
    h && !(Dt = (v.documentElement.doScroll ? /^loaded|^c/ : /^loaded|^i|^c/).test(v.readyState)) && v.addEventListener("DOMContentLoaded", Ct);
    var Rt = function(r, i) {
        return function(t, e, n, a) {
            return r.call(i, t, e, n, a);
        };
    };
    function Ut(t) {
        return 1 !== b(t).length ? null : t.codePointAt(0).toString(16);
    }
    function Yt(a) {
        return Object.keys(a).reduce(function(t, e) {
            var n = a[e];
            return !!n.icon ? t[n.iconName] = n.icon : t[e] = n, t;
        }, {});
    }
    function Jt(t, e, n) {
        var a = (2 < arguments.length && void 0 !== n ? n : {}).skipHooks, a = void 0 !== a && a, r = Yt(e);
        "function" != typeof N.hooks.addPack || a ? N.styles[t] = p(p({}, N.styles[t] || {}), r) : N.hooks.addPack(t, Yt(e)), 
        "fas" === t && Jt("fa", e);
    }
    var Ht, Bt = N.styles, Gt = N.shims, Vt = Object.keys(pt), _t = Vt.reduce(function(t, e) {
        return t[e] = Object.keys(pt[e]), t;
    }, {}), O = null, Xt = {}, qt = {}, Kt = {}, $t = {}, Qt = {};
    function Zt(t, e) {
        var n = e.split("-"), a = n[0], n = n.slice(1).join("-");
        return a !== t || "" === n || ~kt.indexOf(n) ? null : n;
    }
    function te() {
        function t(a) {
            return Wt(Bt, function(t, e, n) {
                return t[n] = Wt(e, a, {}), t;
            }, {});
        }
        Xt = t(function(e, t, n) {
            return t[3] && (e[t[3]] = n), t[2] && t[2].filter(function(t) {
                return "number" == typeof t;
            }).forEach(function(t) {
                e[t.toString(16)] = n;
            }), e;
        }), qt = t(function(e, t, n) {
            return e[n] = n, t[2] && t[2].filter(function(t) {
                return "string" == typeof t;
            }).forEach(function(t) {
                e[t] = n;
            }), e;
        }), Qt = t(function(e, t, n) {
            var a = t[2];
            return e[n] = n, a.forEach(function(t) {
                e[t] = n;
            }), e;
        });
        var i = "far" in Bt || j.autoFetchSvg, e = Wt(Gt, function(t, e) {
            var n = e[0], a = e[1], r = e[2];
            return "far" !== a || i || (a = "fas"), "string" == typeof n && (t.names[n] = {
                prefix: a,
                iconName: r
            }), "number" == typeof n && (t.unicodes[n.toString(16)] = {
                prefix: a,
                iconName: r
            }), t;
        }, {
            names: {},
            unicodes: {}
        });
        Kt = e.names, $t = e.unicodes, O = re(j.styleDefault, {
            family: j.familyDefault
        });
    }
    function ee(t, e) {
        return (Xt[t] || {})[e];
    }
    function E(t, e) {
        return (Qt[t] || {})[e];
    }
    function ne(t) {
        return Kt[t] || {
            prefix: null,
            iconName: null
        };
    }
    Ht = function(t) {
        O = re(t.styleDefault, {
            family: j.familyDefault
        });
    }, St.push(Ht), te();
    var ae = function() {
        return {
            prefix: null,
            iconName: null,
            rest: []
        };
    };
    function re(t, e) {
        var n = (1 < arguments.length && void 0 !== e ? e : {}).family, n = void 0 === n ? g : n, a = ht[n][t];
        return n !== x || t ? (n = gt[n][t] || gt[n][a], a = t in N.styles ? t : null, 
        n || a || null) : "fad";
    }
    function ie(t) {
        return t.sort().filter(function(t, e, n) {
            return n.indexOf(t) === e;
        });
    }
    var oe = et.concat($);
    function se(t, e) {
        var n, a, r, i, o, s, l = (1 < arguments.length && void 0 !== e ? e : {}).skipLookups, l = void 0 !== l && l, f = null, c = ie(t.filter(function(t) {
            return oe.includes(t);
        })), u = ie(t.filter(function(t) {
            return !oe.includes(t);
        })), d = m(c.filter(function(t) {
            return f = t, !_.includes(t);
        }), 1)[0], d = void 0 === d ? null : d, c = (n = c, a = g, r = Vt.reduce(function(t, e) {
            return t[e] = "".concat(j.cssPrefix, "-").concat(e), t;
        }, {}), q.forEach(function(e) {
            (n.includes(r[e]) || n.some(function(t) {
                return _t[e].includes(t);
            })) && (a = e);
        }), a), u = p(p({}, (i = [], o = null, u.forEach(function(t) {
            var e = Zt(j.cssPrefix, t);
            e ? o = e : t && i.push(t);
        }), {
            iconName: o,
            rest: i
        })), {}, {
            prefix: re(d, {
                family: c
            })
        });
        return p(p(p({}, u), (t => {
            var e = t.values, n = t.family, a = t.canonical, r = void 0 === (r = t.givenPrefix) ? "" : r, i = void 0 === (i = t.styles) ? {} : i, o = void 0 === (o = t.config) ? {} : o, s = n === x, l = e.includes("fa-duotone") || e.includes("fad"), f = "duotone" === o.familyDefault, c = "fad" === a.prefix || "fa-duotone" === a.prefix;
            return !s && (l || f || c) && (a.prefix = "fad"), (e.includes("fa-brands") || e.includes("fab")) && (a.prefix = "fab"), 
            !a.prefix && le.includes(n) && (Object.keys(i).find(function(t) {
                return fe.includes(t);
            }) || o.autoFetchSvg) && (s = K.get(n).defaultShortPrefixId, a.prefix = s, 
            a.iconName = E(a.prefix, a.iconName) || a.iconName), "fa" !== a.prefix && "fa" !== r || (a.prefix = O || "fas"), 
            a;
        })({
            values: t,
            family: c,
            styles: Bt,
            config: j,
            canonical: u,
            givenPrefix: f
        })), (e = l, t = f, d = (s = u).prefix, c = s.iconName, !e && d && c && (l = "fa" === t ? ne(c) : {}, 
        u = E(d, c), c = l.iconName || u || c, "far" !== (d = l.prefix || d) || Bt.far || !Bt.fas || j.autoFetchSvg || (d = "fas")), 
        {
            prefix: d,
            iconName: c
        }));
    }
    var le = q.filter(function(t) {
        return t !== g || t !== x;
    }), fe = Object.keys(tt).filter(function(t) {
        return t !== g;
    }).map(function(t) {
        return Object.keys(tt[t]);
    }).flat(), ce = (() => {
        function t() {
            if (!(this instanceof t)) throw new TypeError("Cannot call a class as a function");
            this.definitions = {};
        }
        return e = t, (n = [ {
            key: "add",
            value: function() {
                for (var n = this, t = arguments.length, e = new Array(t), a = 0; a < t; a++) e[a] = arguments[a];
                var r = e.reduce(this._pullDefinitions, {});
                Object.keys(r).forEach(function(t) {
                    n.definitions[t] = p(p({}, n.definitions[t] || {}), r[t]), Jt(t, r[t]);
                    var e = pt[g][t];
                    e && Jt(e, r[t]), te();
                });
            }
        }, {
            key: "reset",
            value: function() {
                this.definitions = {};
            }
        }, {
            key: "_pullDefinitions",
            value: function(i, t) {
                var o = t.prefix && t.iconName && t.icon ? {
                    0: t
                } : t;
                return Object.keys(o).map(function(t) {
                    var e = o[t], n = e.prefix, a = e.iconName, r = e.icon, e = r[2];
                    i[n] || (i[n] = {}), 0 < e.length && e.forEach(function(t) {
                        "string" == typeof t && (i[n][t] = r);
                    }), i[n][a] = r;
                }), i;
            }
        } ]) && T(e.prototype, n), a && T(e, a), Object.defineProperty(e, "prototype", {
            writable: !1
        }), e;
        var e, n, a;
    })(), c = [], C = {}, z = {}, ue = Object.keys(z);
    function de(t, e) {
        for (var n = arguments.length, a = new Array(2 < n ? n - 2 : 0), r = 2; r < n; r++) a[r - 2] = arguments[r];
        return (C[t] || []).forEach(function(t) {
            e = t.apply(null, [ e ].concat(a));
        }), e;
    }
    function D(t) {
        for (var e = arguments.length, n = new Array(1 < e ? e - 1 : 0), a = 1; a < e; a++) n[a - 1] = arguments[a];
        (C[t] || []).forEach(function(t) {
            t.apply(null, n);
        });
    }
    function M(t) {
        var e = t, n = Array.prototype.slice.call(arguments, 1);
        return z[e] ? z[e].apply(null, n) : void 0;
    }
    function me(t) {
        "fa" === t.prefix && (t.prefix = "fas");
        var e = t.iconName, n = t.prefix || O;
        if (e) return e = E(n, e) || e, Tt(he.definitions, n, e) || Tt(N.styles, n, e);
    }
    var he = new ce(), ge = {
        noAuto: function() {
            j.autoReplaceSvg = !1, j.observeMutations = !1, D("noAuto");
        },
        config: j,
        dom: {
            i2svg: function() {
                var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                return h ? (D("beforeI2svg", t), M("pseudoElements2svg", t), M("i2svg", t)) : Promise.reject(new Error("Operation requires a DOM of some kind."));
            },
            watch: function() {
                var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}, e = t.autoReplaceSvgRoot;
                !1 === j.autoReplaceSvg && (j.autoReplaceSvg = !0), j.observeMutations = !0, 
                Mt(function() {
                    pe({
                        autoReplaceSvgRoot: e
                    }), D("watch", t);
                });
            }
        },
        parse: {
            icon: function(t) {
                var e, n;
                return null === t ? null : "object" === Y(t) && t.prefix && t.iconName ? {
                    prefix: t.prefix,
                    iconName: E(t.prefix, t.iconName) || t.iconName
                } : Array.isArray(t) && 2 === t.length ? (e = 0 === t[1].indexOf("fa-") ? t[1].slice(3) : t[1], 
                {
                    prefix: n = re(t[0]),
                    iconName: E(n, e) || e
                }) : "string" == typeof t && (-1 < t.indexOf("".concat(j.cssPrefix, "-")) || t.match(bt)) ? {
                    prefix: (n = se(t.split(" "), {
                        skipLookups: !0
                    })).prefix || O,
                    iconName: E(n.prefix, n.iconName) || n.iconName
                } : "string" == typeof t ? {
                    prefix: O,
                    iconName: E(O, t) || t
                } : void 0;
            }
        },
        library: he,
        findIconDefinition: me,
        toHtml: Lt
    }, pe = function() {
        var t = (0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}).autoReplaceSvgRoot, t = void 0 === t ? v : t;
        (0 < Object.keys(N.styles).length || j.autoFetchSvg) && h && j.autoReplaceSvg && ge.dom.i2svg({
            node: t
        });
    };
    function be(e, t) {
        return Object.defineProperty(e, "abstract", {
            get: t
        }), Object.defineProperty(e, "html", {
            get: function() {
                return e.abstract.map(Lt);
            }
        }), Object.defineProperty(e, "node", {
            get: function() {
                var t;
                if (h) return (t = v.createElement("div")).innerHTML = e.html, t.children;
            }
        }), e;
    }
    function ye(t) {
        var e, n = t.icons, a = n.main, n = n.mask, r = t.prefix, i = t.iconName, o = t.transform, s = t.symbol, l = t.maskId, f = t.extra, c = t.watchable, c = void 0 !== c && c, u = n.found ? n : a, d = u.width, u = u.height, m = [ j.replacementClass, i ? "".concat(j.cssPrefix, "-").concat(i) : "" ].filter(function(t) {
            return -1 === f.classes.indexOf(t);
        }).filter(function(t) {
            return "" !== t || !!t;
        }).concat(f.classes).join(" "), m = {
            children: [],
            attributes: p(p({}, f.attributes), {}, {
                "data-prefix": r,
                "data-icon": i,
                class: m,
                role: f.attributes.role || "img",
                viewBox: "0 0 ".concat(d, " ").concat(u)
            })
        }, d = (e = f.attributes, [ "aria-label", "aria-labelledby", "title", "role" ].some(function(t) {
            return t in e;
        }) || f.attributes["aria-hidden"] || (m.attributes["aria-hidden"] = "true"), 
        c && (m.attributes[w] = ""), p(p({}, m), {}, {
            prefix: r,
            iconName: i,
            main: a,
            mask: n,
            maskId: l,
            transform: o,
            symbol: s,
            styles: p({}, f.styles)
        })), u = n.found && a.found ? M("generateAbstractMask", d) || {
            children: [],
            attributes: {}
        } : M("generateAbstractIcon", d) || {
            children: [],
            attributes: {}
        }, c = u.children, m = u.attributes;
        return d.children = c, d.attributes = m, s ? (r = d.prefix, i = d.iconName, 
        l = d.children, o = d.attributes, r = !0 === (n = d.symbol) ? "".concat(r, "-").concat(j.cssPrefix, "-").concat(i) : n, 
        [ {
            tag: "svg",
            attributes: {
                style: "display: none;"
            },
            children: [ {
                tag: "symbol",
                attributes: p(p({}, o), {}, {
                    id: r
                }),
                children: l
            } ]
        } ]) : (a = (t = d).children, u = t.main, c = t.attributes, It(m = t.transform) && u.found && !t.mask.found && (u = u.width / u.height / 2, 
        s = .5, c.style = Ft(p(p({}, t.styles), {}, {
            "transform-origin": "".concat(u + m.x / 16, "em ").concat(s + m.y / 16, "em")
        }))), [ {
            tag: "svg",
            attributes: c,
            children: a
        } ]);
    }
    function ve(t) {
        var e, n = t.content, a = t.width, r = t.height, i = t.transform, o = t.extra, s = t.watchable, s = void 0 !== s && s, l = p(p({}, o.attributes), {}, {
            class: o.classes.join(" ")
        }), s = (s && (l[w] = ""), p({}, o.styles)), i = (It(i) && (s.transform = (o = (t = {
            transform: i,
            startCentered: !0,
            width: a,
            height: r
        }).transform, i = t.width, a = void 0 === (a = t.height) ? at : a, r = "", 
        r = (r = (r += (e = void 0 !== (e = t.startCentered) && e) && V ? "translate(".concat(o.x / P - (void 0 === i ? at : i) / 2, "em, ").concat(o.y / P - a / 2, "em) ") : e ? "translate(calc(-50% + ".concat(o.x / P, "em), calc(-50% + ").concat(o.y / P, "em)) ") : "translate(".concat(o.x / P, "em, ").concat(o.y / P, "em) ")) + "scale(".concat(o.size / P * (o.flipX ? -1 : 1), ", ").concat(o.size / P * (o.flipY ? -1 : 1), ") ")) + "rotate(".concat(o.rotate, "deg) ")), 
        s["-webkit-transform"] = s.transform), Ft(s)), a = (0 < i.length && (l.style = i), 
        []);
        return a.push({
            tag: "span",
            attributes: l,
            children: [ n ]
        }), a;
    }
    var xe = N.styles;
    function we(t) {
        var e = t[0], n = t[1], a = m(t.slice(4), 1)[0];
        return {
            found: !0,
            width: e,
            height: n,
            icon: Array.isArray(a) ? {
                tag: "g",
                attributes: {
                    class: "".concat(j.cssPrefix, "-").concat(wt.GROUP)
                },
                children: [ {
                    tag: "path",
                    attributes: {
                        class: "".concat(j.cssPrefix, "-").concat(wt.SECONDARY),
                        fill: "currentColor",
                        d: a[0]
                    }
                }, {
                    tag: "path",
                    attributes: {
                        class: "".concat(j.cssPrefix, "-").concat(wt.PRIMARY),
                        fill: "currentColor",
                        d: a[1]
                    }
                } ]
            } : {
                tag: "path",
                attributes: {
                    fill: "currentColor",
                    d: a
                }
            }
        };
    }
    var ke = {
        found: !1,
        width: 512,
        height: 512
    };
    function Se(i, o) {
        var s = o;
        return "fa" === o && null !== j.styleDefault && (o = O), new Promise(function(t, e) {
            var n, a, r;
            if ("fa" === s && (n = ne(i) || {}, i = n.iconName || i, o = n.prefix || o), 
            i && o && xe[o] && xe[o][i]) return t(we(xe[o][i]));
            a = i, r = o, mt || j.showMissingIcons || !a || console.error('Icon with name "'.concat(a, '" and prefix "').concat(r, '" is missing.')), 
            t(p(p({}, ke), {}, {
                icon: j.showMissingIcons && i && M("missingIconAbstract") || {}
            }));
        });
    }
    function Ae() {}
    function je(t) {
        Pe.mark("".concat(Fe, " ").concat(t, " ends")), Pe.measure("".concat(Fe, " ").concat(t), "".concat(Fe, " ").concat(t, " begins"), "".concat(Fe, " ").concat(t, " ends"));
    }
    var Pe = j.measurePerformance && t && t.mark && t.measure ? t : {
        mark: Ae,
        measure: Ae
    }, Fe = 'FA "7.2.0"', Ie = {
        begin: function(t) {
            return Pe.mark("".concat(Fe, " ").concat(t, " begins")), function() {
                return je(t);
            };
        },
        end: je
    }, Ne = function() {};
    function Oe(t) {
        return "string" == typeof (t.getAttribute ? t.getAttribute(w) : null);
    }
    function Ee(t) {
        return v.createElementNS("http://www.w3.org/2000/svg", t);
    }
    function Ce(t) {
        return v.createElement(t);
    }
    var ze = {
        replace: function(t) {
            var e, n = t[0];
            n.parentNode && (t[1].forEach(function(t) {
                n.parentNode.insertBefore(function e(n, t) {
                    var a, r = (1 < arguments.length && void 0 !== t ? t : {}).ceFn, i = void 0 === r ? "svg" === n.tag ? Ee : Ce : r;
                    return "string" == typeof n ? v.createTextNode(n) : (a = i(n.tag), 
                    Object.keys(n.attributes || []).forEach(function(t) {
                        a.setAttribute(t, n.attributes[t]);
                    }), (n.children || []).forEach(function(t) {
                        a.appendChild(e(t, {
                            ceFn: i
                        }));
                    }), a);
                }(t), n);
            }), null === n.getAttribute(w) && j.keepOriginalSource ? (e = v.createComment((e = " ".concat(n.outerHTML, " "), 
            "".concat(e, "Font Awesome fontawesome.com "))), n.parentNode.replaceChild(e, n)) : n.remove());
        },
        nest: function(t) {
            var e = t[0], n = t[1];
            if (~jt(e).indexOf(j.replacementClass)) return ze.replace(t);
            var a = new RegExp("".concat(j.cssPrefix, "-.*")), r = (delete n[0].attributes.id, 
            n[0].attributes.class && (r = n[0].attributes.class.split(" ").reduce(function(t, e) {
                return (e === j.replacementClass || e.match(a) ? t.toSvg : t.toNode).push(e), 
                t;
            }, {
                toNode: [],
                toSvg: []
            }), n[0].attributes.class = r.toSvg.join(" "), 0 === r.toNode.length ? e.removeAttribute("class") : e.setAttribute("class", r.toNode.join(" "))), 
            n.map(Lt).join("\n"));
            e.setAttribute(w, ""), e.innerHTML = r;
        }
    };
    function De(t) {
        t();
    }
    function Me(n, t) {
        var a = "function" == typeof t ? t : Ne;
        0 === n.length ? a() : (j.mutateApproach === ct ? y.requestAnimationFrame || De : De)(function() {
            var t = !0 !== j.autoReplaceSvg && ze[j.autoReplaceSvg] || ze.replace, e = Ie.begin("mutate");
            n.map(t), e(), a();
        });
    }
    var Le = !1;
    function Te() {
        Le = !0;
    }
    function We() {
        Le = !1;
    }
    var Re = null;
    function Ue(t) {
        var i, o, s, e;
        B && j.observeMutations && (e = t.treeCallback, i = void 0 === e ? Ne : e, 
        o = void 0 === (e = t.nodeCallback) ? Ne : e, s = void 0 === (e = t.pseudoElementsCallback) ? Ne : e, 
        e = void 0 === (e = t.observeMutationsRoot) ? v : e, Re = new B(function(t) {
            var r;
            Le || (r = O, I(t).forEach(function(t) {
                var e, n, a;
                "childList" === t.type && 0 < t.addedNodes.length && !Oe(t.addedNodes[0]) && (j.searchPseudoElements && s(t.target), 
                i(t.target)), "attributes" === t.type && t.target.parentNode && j.searchPseudoElements && s([ t.target ], !0), 
                "attributes" === t.type && Oe(t.target) && ~xt.indexOf(t.attributeName) && ("class" === t.attributeName && (e = t.target, 
                n = e.getAttribute ? e.getAttribute(st) : null, a = e.getAttribute ? e.getAttribute(lt) : null, 
                n) && a ? (a = (n = se(jt(t.target))).prefix, n = n.iconName, t.target.setAttribute(st, a || r), 
                n && t.target.setAttribute(lt, n)) : (e = t.target) && e.classList && e.classList.contains && e.classList.contains(j.replacementClass) && o(t.target));
            }));
        }), h) && Re.observe(e, {
            childList: !0,
            attributes: !0,
            characterData: !0,
            subtree: !0
        });
    }
    function Ye(t) {
        var e, n, a = t.getAttribute("data-prefix"), r = t.getAttribute("data-icon"), i = void 0 !== t.innerText ? t.innerText.trim() : "", o = se(jt(t));
        return o.prefix || (o.prefix = O), a && r && (o.prefix = a, o.iconName = r), 
        o.iconName && o.prefix || (o.prefix && 0 < i.length && (o.iconName = (e = o.prefix, 
        n = t.innerText, (qt[e] || {})[n] || ee(o.prefix, Ut(t.innerText)))), !o.iconName && j.autoFetchSvg && t.firstChild && t.firstChild.nodeType === Node.TEXT_NODE && (o.iconName = t.firstChild.data)), 
        o;
    }
    function Je(t, e) {
        var n, a = 1 < arguments.length && void 0 !== e ? e : {
            styleParser: !0
        }, r = Ye(t), i = r.iconName, o = r.prefix, r = r.rest, s = I(t.attributes).reduce(function(t, e) {
            return "class" !== t.name && "style" !== t.name && (t[e.name] = e.value), 
            t;
        }, {}), l = de("parseNodeAttributes", {}, t), a = a.styleParser ? (a = t.getAttribute("style"), 
        n = [], n = a ? a.split(";").reduce(function(t, e) {
            var n = e.split(":"), a = n[0], n = n.slice(1);
            return a && 0 < n.length && (t[a] = n.join(":").trim()), t;
        }, {}) : n) : [];
        return p({
            iconName: i,
            prefix: o,
            transform: F,
            mask: {
                iconName: null,
                prefix: null,
                rest: []
            },
            maskId: null,
            symbol: !1,
            extra: {
                classes: r,
                styles: a,
                attributes: s
            }
        }, l);
    }
    var He = N.styles;
    function Be(t) {
        var e = "nest" === j.autoReplaceSvg ? Je(t, {
            styleParser: !1
        }) : Je(t);
        return ~e.extra.classes.indexOf(yt) ? M("generateLayersText", t, e) : M("generateSvgReplacementMutation", t, e);
    }
    function Ge(t) {
        var a = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null;
        if (!h) return Promise.resolve();
        function r(t) {
            e.add("".concat(ft, "-").concat(t));
        }
        function i(t) {
            e.remove("".concat(ft, "-").concat(t));
        }
        var e = v.documentElement.classList, n = j.autoFetchSvg ? [].concat(b($), b(et)) : _.concat(Object.keys(He)), n = (n.includes("fa") || n.push("fa"), 
        [ ".".concat(yt, ":not([").concat(w, "])") ].concat(n.map(function(t) {
            return ".".concat(t, ":not([").concat(w, "])");
        })).join(", "));
        if (0 === n.length) return Promise.resolve();
        var o = [];
        try {
            o = I(t.querySelectorAll(n));
        } catch (t) {}
        if (!(0 < o.length)) return Promise.resolve();
        r("pending"), i("complete");
        var s = Ie.begin("onTree"), l = o.reduce(function(t, e) {
            try {
                var n = Be(e);
                n && t.push(n);
            } catch (t) {
                mt || "MissingIcon" === t.name && console.error(t);
            }
            return t;
        }, []);
        return new Promise(function(e, n) {
            Promise.all(l).then(function(t) {
                Me(t, function() {
                    r("active"), r("complete"), i("pending"), "function" == typeof a && a(), 
                    s(), e();
                });
            }).catch(function(t) {
                s(), n(t);
            });
        });
    }
    function Ve(t) {
        var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null;
        Be(t).then(function(t) {
            t && Me([ t ], e);
        });
    }
    function _e(t) {
        var e, n, a, r = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, i = r.transform, o = void 0 === i ? F : i, s = void 0 !== (i = r.symbol) && i, l = void 0 === (i = r.mask) ? null : i, f = void 0 === (i = r.maskId) ? null : i, c = void 0 === (i = r.classes) ? [] : i, u = void 0 === (i = r.attributes) ? {} : i, d = void 0 === (i = r.styles) ? {} : i;
        if (t) return e = t.prefix, n = t.iconName, a = t.icon, be(p({
            type: "icon"
        }, t), function() {
            return D("beforeDOMElementCreation", {
                iconDefinition: t,
                params: r
            }), ye({
                icons: {
                    main: we(a),
                    mask: l ? we(l.icon) : {
                        found: !1,
                        width: null,
                        height: null,
                        icon: {}
                    }
                },
                prefix: e,
                iconName: n,
                transform: p(p({}, F), o),
                symbol: s,
                maskId: f,
                extra: {
                    attributes: u,
                    styles: d,
                    classes: c
                }
            });
        });
    }
    var e = {
        mixout: function() {
            return {
                icon: (r = _e, function(t) {
                    var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, n = (t || {}).icon ? t : me(t || {}), a = (a = e.mask) && ((a || {}).icon ? a : me(a || {}));
                    return r(n, p(p({}, e), {}, {
                        mask: a
                    }));
                })
            };
            var r;
        },
        hooks: function() {
            return {
                mutationObserverCallbacks: function(t) {
                    return t.treeCallback = Ge, t.nodeCallback = Ve, t;
                }
            };
        },
        provides: function(t) {
            t.i2svg = function(t) {
                var e = t.node, n = t.callback;
                return Ge(void 0 === e ? v : e, void 0 === n ? function() {} : n);
            }, t.generateSvgReplacementMutation = function(r, t) {
                var i = t.iconName, o = t.prefix, s = t.transform, l = t.symbol, e = t.mask, f = t.maskId, c = t.extra;
                return new Promise(function(a, t) {
                    Promise.all([ Se(i, o), e.iconName ? Se(e.iconName, e.prefix) : Promise.resolve({
                        found: !1,
                        width: 512,
                        height: 512,
                        icon: {}
                    }) ]).then(function(t) {
                        var e = m(t, 2), n = e[0];
                        a([ r, ye({
                            icons: {
                                main: n,
                                mask: e[1]
                            },
                            prefix: o,
                            iconName: i,
                            transform: s,
                            symbol: l,
                            maskId: f,
                            extra: c,
                            watchable: !0
                        }) ]);
                    }).catch(t);
                });
            }, t.generateAbstractIcon = function(t) {
                var e, n = t.children, a = t.attributes, r = t.main, i = t.transform, o = Ft(t.styles);
                return 0 < o.length && (a.style = o), It(i) && (e = M("generateAbstractTransformGrouping", {
                    main: r,
                    transform: i,
                    containerWidth: r.width,
                    iconWidth: r.width
                })), n.push(e || r.icon), {
                    children: n,
                    attributes: a
                };
            };
        }
    }, n = {
        mixout: function() {
            return {
                layer: function(t) {
                    var n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, e = n.classes, a = void 0 === e ? [] : e;
                    return be({
                        type: "layer"
                    }, function() {
                        D("beforeDOMElementCreation", {
                            assembler: t,
                            params: n
                        });
                        var e = [];
                        return t(function(t) {
                            Array.isArray(t) ? t.map(function(t) {
                                e = e.concat(t.abstract);
                            }) : e = e.concat(t.abstract);
                        }), [ {
                            tag: "span",
                            attributes: {
                                class: [ "".concat(j.cssPrefix, "-layers") ].concat(b(a)).join(" ")
                            },
                            children: e
                        } ];
                    });
                }
            };
        }
    }, r = {
        mixout: function() {
            return {
                counter: function(r) {
                    var i = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, t = i.title, o = void 0 === t ? null : t, t = i.classes, s = void 0 === t ? [] : t, t = i.attributes, l = void 0 === t ? {} : t, t = i.styles, f = void 0 === t ? {} : t;
                    return be({
                        type: "counter",
                        content: r
                    }, function() {
                        return D("beforeDOMElementCreation", {
                            content: r,
                            params: i
                        }), t = {
                            content: r.toString(),
                            title: o,
                            extra: {
                                attributes: l,
                                styles: f,
                                classes: [ "".concat(j.cssPrefix, "-layers-counter") ].concat(b(s))
                            }
                        }, e = t.content, a = p(p({}, (n = t.extra).attributes), {}, {
                            class: n.classes.join(" ")
                        }), 0 < (n = Ft(n.styles)).length && (a.style = n), (n = []).push({
                            tag: "span",
                            attributes: a,
                            children: [ e ]
                        }), n;
                        var t, e, n, a;
                    });
                }
            };
        }
    }, Xe = {
        mixout: function() {
            return {
                text: function(t) {
                    var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, n = e.transform, a = void 0 === n ? F : n, n = e.classes, r = void 0 === n ? [] : n, n = e.attributes, i = void 0 === n ? {} : n, n = e.styles, o = void 0 === n ? {} : n;
                    return be({
                        type: "text",
                        content: t
                    }, function() {
                        return D("beforeDOMElementCreation", {
                            content: t,
                            params: e
                        }), ve({
                            content: t,
                            transform: p(p({}, F), a),
                            extra: {
                                attributes: i,
                                styles: o,
                                classes: [ "".concat(j.cssPrefix, "-layers-text") ].concat(b(r))
                            }
                        });
                    });
                }
            };
        },
        provides: function(t) {
            t.generateLayersText = function(t, e) {
                var n, a, r = e.transform, i = e.extra, o = null, s = null;
                return V && (n = parseInt(getComputedStyle(t).fontSize, 10), o = (a = t.getBoundingClientRect()).width / n, 
                s = a.height / n), Promise.resolve([ t, ve({
                    content: t.innerHTML,
                    width: o,
                    height: s,
                    transform: r,
                    extra: i,
                    watchable: !0
                }) ]);
            };
        }
    }, qe = new RegExp('"', "ug"), Ke = [ 1105920, 1112319 ], $e = p(p(p(p({}, {
        FontAwesome: {
            normal: "fas",
            400: "fas"
        }
    }), {
        "Font Awesome 7 Free": {
            900: "fas",
            400: "far"
        },
        "Font Awesome 7 Pro": {
            900: "fas",
            400: "far",
            normal: "far",
            300: "fal",
            100: "fat"
        },
        "Font Awesome 7 Brands": {
            400: "fab",
            normal: "fab"
        },
        "Font Awesome 7 Duotone": {
            900: "fad",
            400: "fadr",
            normal: "fadr",
            300: "fadl",
            100: "fadt"
        },
        "Font Awesome 7 Sharp": {
            900: "fass",
            400: "fasr",
            normal: "fasr",
            300: "fasl",
            100: "fast"
        },
        "Font Awesome 7 Sharp Duotone": {
            900: "fasds",
            400: "fasdr",
            normal: "fasdr",
            300: "fasdl",
            100: "fasdt"
        },
        "Font Awesome 7 Jelly": {
            400: "fajr",
            normal: "fajr"
        },
        "Font Awesome 7 Jelly Fill": {
            400: "fajfr",
            normal: "fajfr"
        },
        "Font Awesome 7 Jelly Duo": {
            400: "fajdr",
            normal: "fajdr"
        },
        "Font Awesome 7 Slab": {
            400: "faslr",
            normal: "faslr"
        },
        "Font Awesome 7 Slab Press": {
            400: "faslpr",
            normal: "faslpr"
        },
        "Font Awesome 7 Thumbprint": {
            300: "fatl",
            normal: "fatl"
        },
        "Font Awesome 7 Notdog": {
            900: "fans",
            normal: "fans"
        },
        "Font Awesome 7 Notdog Duo": {
            900: "fands",
            normal: "fands"
        },
        "Font Awesome 7 Etch": {
            900: "faes",
            normal: "faes"
        },
        "Font Awesome 7 Graphite": {
            100: "fagt",
            normal: "fagt"
        },
        "Font Awesome 7 Chisel": {
            400: "facr",
            normal: "facr"
        },
        "Font Awesome 7 Whiteboard": {
            600: "fawsb",
            normal: "fawsb"
        },
        "Font Awesome 7 Utility": {
            600: "fausb",
            normal: "fausb"
        },
        "Font Awesome 7 Utility Duo": {
            600: "faudsb",
            normal: "faudsb"
        },
        "Font Awesome 7 Utility Fill": {
            600: "faufsb",
            normal: "faufsb"
        }
    }), {
        "Font Awesome 5 Free": {
            900: "fas",
            400: "far"
        },
        "Font Awesome 5 Pro": {
            900: "fas",
            400: "far",
            normal: "far",
            300: "fal"
        },
        "Font Awesome 5 Brands": {
            400: "fab",
            normal: "fab"
        },
        "Font Awesome 5 Duotone": {
            900: "fad"
        }
    }), {
        "Font Awesome Kit": {
            400: "fak",
            normal: "fak"
        },
        "Font Awesome Kit Duotone": {
            400: "fakd",
            normal: "fakd"
        }
    }), Qe = Object.keys($e).reduce(function(t, e) {
        return t[e.toLowerCase()] = $e[e], t;
    }, {}), Ze = Object.keys(Qe).reduce(function(t, e) {
        var n = Qe[e];
        return t[e] = n[900] || b(Object.entries(n))[0][1], t;
    }, {});
    function tn(m, h) {
        var g = "".concat(ot).concat(h.replace(":", "-"));
        return new Promise(function(a, t) {
            var e, r, i, o, s, n, l, f, c, u, d;
            return null !== m.getAttribute(g) ? a() : (e = I(m.children).filter(function(t) {
                return t.getAttribute(it) === h;
            })[0], f = y.getComputedStyle(m, h), l = (d = f.getPropertyValue("font-family")).match(vt), 
            u = f.getPropertyValue("font-weight"), n = f.getPropertyValue("content"), 
            e && !l ? (m.removeChild(e), a()) : void (!l || "none" === n || "" === n || (n = f.getPropertyValue("content"), 
            c = u, u = d.replace(/^['"]|['"]$/g, "").toLowerCase(), d = parseInt(c), 
            d = isNaN(d) ? "normal" : d, r = (Qe[u] || {})[d] || Ze[u], d = Ut(b(n.replace(qe, ""))[0] || ""), 
            u = l[0].startsWith("FontAwesome"), n = (c = f).getPropertyValue("font-feature-settings").includes("ss01"), 
            l = c.getPropertyValue("content").replace(qe, ""), f = (f = l.codePointAt(0)) >= Ke[0] && f <= Ke[1], 
            l = 2 === l.length && l[0] === l[1], f = f || l || n, l = ee(r, d), 
            i = l, u && (n = $t[d], u = ee("fas", d), (d = n || (u ? {
                prefix: "fas",
                iconName: u
            } : null) || {
                prefix: null,
                iconName: null
            }).iconName) && d.prefix && (l = d.iconName, r = d.prefix), !l) || f || e && e.getAttribute(st) === r && e.getAttribute(lt) === i ? a() : (m.setAttribute(g, i), 
            e && m.removeChild(e), (s = (o = {
                iconName: null,
                prefix: null,
                transform: F,
                symbol: !1,
                mask: {
                    iconName: null,
                    prefix: null,
                    rest: []
                },
                maskId: null,
                extra: {
                    classes: [],
                    styles: {},
                    attributes: {}
                }
            }).extra).attributes[it] = h, Se(l, r).then(function(t) {
                var e = ye(p(p({}, o), {}, {
                    icons: {
                        main: t,
                        mask: ae()
                    },
                    prefix: r,
                    iconName: i,
                    extra: s,
                    watchable: !0
                })), n = v.createElementNS("http://www.w3.org/2000/svg", "svg");
                "::before" === h ? m.insertBefore(n, m.firstChild) : m.appendChild(n), 
                n.outerHTML = e.map(Lt).join("\n"), m.removeAttribute(g), a();
            }).catch(t))));
        });
    }
    function en(t) {
        return Promise.all([ tn(t, "::before"), tn(t, "::after") ]);
    }
    function nn(t) {
        return !(t.parentNode === document.head || ~ut.indexOf(t.tagName.toUpperCase()) || t.getAttribute(it) || t.parentNode && "svg" === t.parentNode.tagName);
    }
    var an = function(e) {
        return !!e && dt.some(function(t) {
            return e.includes(t);
        });
    };
    function rn(t) {
        var r, e = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
        if (h) {
            if (e) r = t; else if (j.searchPseudoElementsFullScan) r = t.querySelectorAll("*"); else {
                var n, a = new Set(), i = W(document.styleSheets);
                try {
                    for (i.s(); !(n = i.n()).done; ) {
                        var o = n.value;
                        try {
                            var s, l = W(o.cssRules);
                            try {
                                for (l.s(); !(s = l.n()).done; ) {
                                    var f, c = (t => {
                                        if (!t) return [];
                                        var e, n = new Set(), a = W(t.split(/,(?![^()]*\))/).map(function(t) {
                                            return t.trim();
                                        }).flatMap(function(t) {
                                            return t.includes("(") ? t : t.split(",").map(function(t) {
                                                return t.trim();
                                            });
                                        }));
                                        try {
                                            for (a.s(); !(e = a.n()).done; ) {
                                                var r, i = e.value;
                                                an(i) && "" !== (r = dt.reduce(function(t, e) {
                                                    return t.replace(e, "");
                                                }, i)) && "*" !== r && n.add(r);
                                            }
                                        } catch (t) {
                                            a.e(t);
                                        } finally {
                                            a.f();
                                        }
                                        return n;
                                    })(s.value.selectorText), u = W(c);
                                    try {
                                        for (u.s(); !(f = u.n()).done; ) {
                                            var d = f.value;
                                            a.add(d);
                                        }
                                    } catch (t) {
                                        u.e(t);
                                    } finally {
                                        u.f();
                                    }
                                }
                            } catch (t) {
                                l.e(t);
                            } finally {
                                l.f();
                            }
                        } catch (t) {
                            j.searchPseudoElementsWarnings && console.warn("Font Awesome: cannot parse stylesheet: ".concat(o.href, " (").concat(t.message, ')\nIf it declares any Font Awesome CSS pseudo-elements, they will not be rendered as SVG icons. Add crossorigin="anonymous" to the <link>, enable searchPseudoElementsFullScan for slower but more thorough DOM parsing, or suppress this warning by setting searchPseudoElementsWarnings to false.'));
                        }
                    }
                } catch (t) {
                    i.e(t);
                } finally {
                    i.f();
                }
                if (!a.size) return;
                e = Array.from(a).join(", ");
                try {
                    r = t.querySelectorAll(e);
                } catch (t) {}
            }
            return new Promise(function(t, e) {
                var n = I(r).filter(nn).map(en), a = Ie.begin("searchPseudoElements");
                Te(), Promise.all(n).then(function() {
                    a(), We(), t();
                }).catch(function() {
                    a(), We(), e();
                });
            });
        }
    }
    function on(t) {
        return t.toLowerCase().split(" ").reduce(function(t, e) {
            var n = e.toLowerCase().split("-"), a = n[0], r = n.slice(1).join("-");
            if (a && "h" === r) t.flipX = !0; else if (a && "v" === r) t.flipY = !0; else if (r = parseFloat(r), 
            !isNaN(r)) switch (a) {
              case "grow":
                t.size = t.size + r;
                break;

              case "shrink":
                t.size = t.size - r;
                break;

              case "left":
                t.x = t.x - r;
                break;

              case "right":
                t.x = t.x + r;
                break;

              case "up":
                t.y = t.y - r;
                break;

              case "down":
                t.y = t.y + r;
                break;

              case "rotate":
                t.rotate = t.rotate + r;
            }
            return t;
        }, {
            size: 16,
            x: 0,
            y: 0,
            flipX: !1,
            flipY: !1,
            rotate: 0
        });
    }
    var sn, ln = !1, fn = {
        x: 0,
        y: 0,
        width: "100%",
        height: "100%"
    };
    function cn(t) {
        return t.attributes && (t.attributes.fill || (!(1 < arguments.length && void 0 !== arguments[1]) || arguments[1])) && (t.attributes.fill = "black"), 
        t;
    }
    sn = {
        mixoutsTo: ge
    }.mixoutsTo, c = [ Z, e, n, r, Xe, {
        hooks: function() {
            return {
                mutationObserverCallbacks: function(t) {
                    return t.pseudoElementsCallback = rn, t;
                }
            };
        },
        provides: function(t) {
            t.pseudoElements2svg = function(t) {
                var e = t.node;
                j.searchPseudoElements && rn(void 0 === e ? v : e);
            };
        }
    }, {
        mixout: function() {
            return {
                dom: {
                    unwatch: function() {
                        Te(), ln = !0;
                    }
                }
            };
        },
        hooks: function() {
            return {
                bootstrap: function() {
                    Ue(de("mutationObserverCallbacks", {}));
                },
                noAuto: function() {
                    Re && Re.disconnect();
                },
                watch: function(t) {
                    var e = t.observeMutationsRoot;
                    ln ? We() : Ue(de("mutationObserverCallbacks", {
                        observeMutationsRoot: e
                    }));
                }
            };
        }
    }, {
        mixout: function() {
            return {
                parse: {
                    transform: on
                }
            };
        },
        hooks: function() {
            return {
                parseNodeAttributes: function(t, e) {
                    var n = e.getAttribute("data-fa-transform");
                    return n && (t.transform = on(n)), t;
                }
            };
        },
        provides: function(t) {
            t.generateAbstractTransformGrouping = function(t) {
                var e = t.main, n = t.transform, a = t.iconWidth, r = {
                    transform: "translate(".concat(t.containerWidth / 2, " 256)")
                }, i = "translate(".concat(32 * n.x, ", ").concat(32 * n.y, ") "), o = "scale(".concat(n.size / 16 * (n.flipX ? -1 : 1), ", ").concat(n.size / 16 * (n.flipY ? -1 : 1), ") "), n = "rotate(".concat(n.rotate, " 0 0)"), r = {
                    outer: r,
                    inner: {
                        transform: "".concat(i, " ").concat(o, " ").concat(n)
                    },
                    path: {
                        transform: "translate(".concat(a / 2 * -1, " -256)")
                    }
                };
                return {
                    tag: "g",
                    attributes: p({}, r.outer),
                    children: [ {
                        tag: "g",
                        attributes: p({}, r.inner),
                        children: [ {
                            tag: e.icon.tag,
                            children: e.icon.children,
                            attributes: p(p({}, e.icon.attributes), r.path)
                        } ]
                    } ]
                };
            };
        }
    }, {
        hooks: function() {
            return {
                parseNodeAttributes: function(t, e) {
                    var n = e.getAttribute("data-fa-mask"), n = n ? se(n.split(" ").map(function(t) {
                        return t.trim();
                    })) : ae();
                    return n.prefix || (n.prefix = O), t.mask = n, t.maskId = e.getAttribute("data-fa-mask-id"), 
                    t;
                }
            };
        },
        provides: function(t) {
            t.generateAbstractMask = function(t) {
                var e = t.children, n = t.attributes, a = t.main, r = t.mask, i = t.maskId, o = a.width, a = a.icon, s = r.width, r = r.icon, l = (s = (t = {
                    transform: t.transform,
                    containerWidth: s,
                    iconWidth: o
                }).transform, o = t.iconWidth, l = {
                    transform: "translate(".concat(t.containerWidth / 2, " 256)")
                }, f = "translate(".concat(32 * s.x, ", ").concat(32 * s.y, ") "), 
                c = "scale(".concat(s.size / 16 * (s.flipX ? -1 : 1), ", ").concat(s.size / 16 * (s.flipY ? -1 : 1), ") "), 
                s = "rotate(".concat(s.rotate, " 0 0)"), {
                    outer: l,
                    inner: {
                        transform: "".concat(f, " ").concat(c, " ").concat(s)
                    },
                    path: {
                        transform: "translate(".concat(o / 2 * -1, " -256)")
                    }
                }), f = {
                    tag: "rect",
                    attributes: p(p({}, fn), {}, {
                        fill: "white"
                    })
                }, c = a.children ? {
                    children: a.children.map(cn)
                } : {}, s = {
                    tag: "g",
                    attributes: p({}, l.inner),
                    children: [ cn(p({
                        tag: a.tag,
                        attributes: p(p({}, a.attributes), l.path)
                    }, c)) ]
                }, o = {
                    tag: "g",
                    attributes: p({}, l.outer),
                    children: [ s ]
                }, a = "mask-".concat(i || At()), c = "clip-".concat(i || At()), l = {
                    tag: "mask",
                    attributes: p(p({}, fn), {}, {
                        id: a,
                        maskUnits: "userSpaceOnUse",
                        maskContentUnits: "userSpaceOnUse"
                    }),
                    children: [ f, o ]
                }, s = {
                    tag: "defs",
                    children: [ {
                        tag: "clipPath",
                        attributes: {
                            id: c
                        },
                        children: "g" === (t = r).tag ? t.children : [ t ]
                    }, l ]
                };
                return e.push(s, {
                    tag: "rect",
                    attributes: p({
                        fill: "currentColor",
                        "clip-path": "url(#".concat(c, ")"),
                        mask: "url(#".concat(a, ")")
                    }, fn)
                }), {
                    children: e,
                    attributes: n
                };
            };
        }
    }, {
        provides: function(t) {
            var i = !1;
            y.matchMedia && (i = y.matchMedia("(prefers-reduced-motion: reduce)").matches), 
            t.missingIconAbstract = function() {
                var t = [], e = {
                    fill: "currentColor"
                }, n = {
                    attributeType: "XML",
                    repeatCount: "indefinite",
                    dur: "2s"
                }, a = (t.push({
                    tag: "path",
                    attributes: p(p({}, e), {}, {
                        d: "M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"
                    })
                }), p(p({}, n), {}, {
                    attributeName: "opacity"
                })), r = {
                    tag: "circle",
                    attributes: p(p({}, e), {}, {
                        cx: "256",
                        cy: "364",
                        r: "28"
                    }),
                    children: []
                };
                return i || r.children.push({
                    tag: "animate",
                    attributes: p(p({}, n), {}, {
                        attributeName: "r",
                        values: "28;14;28;28;14;28;"
                    })
                }, {
                    tag: "animate",
                    attributes: p(p({}, a), {}, {
                        values: "1;0;1;1;0;1;"
                    })
                }), t.push(r), t.push({
                    tag: "path",
                    attributes: p(p({}, e), {}, {
                        opacity: "1",
                        d: "M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"
                    }),
                    children: i ? [] : [ {
                        tag: "animate",
                        attributes: p(p({}, a), {}, {
                            values: "1;0;0;0;0;1;"
                        })
                    } ]
                }), i || t.push({
                    tag: "path",
                    attributes: p(p({}, e), {}, {
                        opacity: "0",
                        d: "M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"
                    }),
                    children: [ {
                        tag: "animate",
                        attributes: p(p({}, a), {}, {
                            values: "0;0;1;1;0;0;"
                        })
                    } ]
                }), {
                    tag: "g",
                    attributes: {
                        class: "missing"
                    },
                    children: t
                };
            };
        }
    }, {
        hooks: function() {
            return {
                parseNodeAttributes: function(t, e) {
                    var n = e.getAttribute("data-fa-symbol");
                    return t.symbol = null !== n && ("" === n || n), t;
                }
            };
        }
    } ], C = {}, Object.keys(z).forEach(function(t) {
        -1 === ue.indexOf(t) && delete z[t];
    }), c.forEach(function(t) {
        var e, n = t.mixout ? t.mixout() : {};
        Object.keys(n).forEach(function(e) {
            "function" == typeof n[e] && (sn[e] = n[e]), "object" === Y(n[e]) && Object.keys(n[e]).forEach(function(t) {
                sn[e] || (sn[e] = {}), sn[e][t] = n[e][t];
            });
        }), t.hooks && (e = t.hooks(), Object.keys(e).forEach(function(t) {
            C[t] || (C[t] = []), C[t].push(e[t]);
        })), t.provides && t.provides(z);
    }), function(t) {
        try {
            for (var e = arguments.length, n = new Array(1 < e ? e - 1 : 0), a = 1; a < e; a++) n[a - 1] = arguments[a];
            t.apply(void 0, n);
        } catch (t) {
            if (!mt) throw t;
        }
    }(function() {
        G && (y.FontAwesome || (y.FontAwesome = ge), Mt(function() {
            pe(), D("bootstrap");
        })), N.hooks = p(p({}, N.hooks), {}, {
            addPack: function(t, e) {
                N.styles[t] = p(p({}, N.styles[t] || {}), e), te(), pe();
            },
            addPacks: function(t) {
                t.forEach(function(t) {
                    var e = m(t, 2), n = e[0], e = e[1];
                    N.styles[n] = p(p({}, N.styles[n] || {}), e);
                }), te(), pe();
            },
            addShims: function(t) {
                var e;
                (e = N.shims).push.apply(e, b(t)), te(), pe();
            }
        });
    });
})();