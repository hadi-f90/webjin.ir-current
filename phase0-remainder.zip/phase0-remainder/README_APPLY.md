# Phase 0 remainder — apply instructions

## Already done on tip (`92b7895` / PR #6–#7)

- [x] `WebsiteSubmitForm` full Meta fields
- [x] `QuickSubmitForm` Meta `fields = ['title', 'url']` + captcha extra field
- [x] Env-driven `settings.py` (no plaintext DB password on tip)
- [x] `website_card.html` `{% load farsi_tags %}`
- [x] `.env.example` present

## Still broken on tip — this package

| Item | Path |
|------|------|
| Commands `__init__.py` still contains CSV command + `websites.models` | → empty `__init__.py` |
| `import_websites.py` empty | → full CSV command using `directory.models` |
| `import_websites_json.py` uses `your_app.models.WebsiteResource` | → `directory.models.Website` |
| `delete_tag_ajax` uses `tag.websites` | → `tag.websites_tagged` |
| `500/404/403` templates use `websites:`, `pages:`, `accounts:` | → real names: `index`, `contact_page`, `login`, … |

## Apply

```bash
cd /path/to/webjin.ir-current

# Management commands
cp path/to/phase0-remainder/directory/management/commands/__init__.py \
   directory/management/commands/__init__.py
cp path/to/phase0-remainder/directory/management/commands/import_websites.py \
   directory/management/commands/import_websites.py
cp path/to/phase0-remainder/directory/management/commands/import_websites_json.py \
   directory/management/commands/import_websites_json.py

# Error templates
cp path/to/phase0-remainder/templates/500.html templates/500.html
cp path/to/phase0-remainder/templates/404.html templates/404.html
cp path/to/phase0-remainder/templates/403.html templates/403.html

# delete_tag_ajax — two substitutions in directory/views.py
python3 - <<'PY'
from pathlib import Path
p = Path("directory/views.py")
text = p.read_text(encoding="utf-8")
old = "tag.websites"
if "tag.websites_tagged" in text and "tag.websites.exists" not in text.replace("tag.websites_tagged", ""):
    print("already patched or no tag.websites left")
else:
    text2 = text.replace("tag.websites.exists()", "tag.websites_tagged.exists()")
    text2 = text2.replace("tag.websites.count()", "tag.websites_tagged.count()")
    if text2 == text:
        print("WARNING: patterns not found — apply manually from delete_tag_ajax_snippet.py")
    else:
        p.write_text(text2, encoding="utf-8")
        print("views.py: tag.websites → tag.websites_tagged")
PY

# Verify commands load
python manage.py check
python -c "import directory.management.commands.import_websites as m; print('csv cmd OK', m.Command.help)"
python -c "import directory.management.commands.import_websites_json as m; print('json cmd OK', m.Command.help)"
```

Optional: re-run `python manage.py test directory.tests.AjaxTagEndpointTests` after the tag fix.

## Phase 0 complete when

- [x] Forms Metas correct  
- [x] Settings env-driven on tip  
- [x] website_card loads farsi_tags  
- [ ] Commands import `directory.models` only  
- [ ] `delete_tag_ajax` uses `websites_tagged`  
- [ ] Error templates use real URL names  
- [ ] `manage.py check` clean; management commands import without `websites` / `your_app`

Password rotation on the MySQL host remains a **server** task (history still had the old password).
